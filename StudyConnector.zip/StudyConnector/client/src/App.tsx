import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import SimpleAuthPage from "@/pages/simple-auth-page";
import DashboardPage from "@/pages/dashboard-page";
import FindBuddiesPage from "@/pages/find-buddies-page";
import FindGroupsPage from "@/pages/find-groups-page";
import CreateGroupPage from "@/pages/create-group-page";
import ProfilePage from "@/pages/profile-page";
import SplashScreen from "./components/splash-screen";
import { useState, useEffect } from "react";
import { Loader2 } from "lucide-react";
import { apiRequest, queryClient } from "./lib/queryClient";
import { User } from "@shared/schema";

export default function App(): JSX.Element {
  const [showSplash, setShowSplash] = useState(true);
  const [user, setUser] = useState<User | null>(null);
  const [isLoadingUser, setIsLoadingUser] = useState(true);

  // Handle splash screen timer
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  // Check if user is authenticated
  useEffect(() => {
    async function checkAuth() {
      try {
        const res = await fetch("/api/user", {
          credentials: "include",
          headers: {
            "Accept": "application/json"
          }
        });
        
        if (res.ok) {
          const userData = await res.json();
          console.log("User authenticated:", userData);
          setUser(userData);
          queryClient.setQueryData(["/api/user"], userData);
        } else {
          console.log("User not authenticated, status:", res.status);
          setUser(null);
          queryClient.setQueryData(["/api/user"], null);
        }
      } catch (error) {
        console.error("Authentication check error:", error);
        setUser(null);
        queryClient.setQueryData(["/api/user"], null);
      } finally {
        setIsLoadingUser(false);
      }
    }

    checkAuth();
  }, []);

  // Show splash screen
  if (showSplash) {
    return <SplashScreen />;
  }

  // Show loading state when checking auth
  if (isLoadingUser) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <>
      <Switch>
        {/* Routes that require authentication */}
        {user ? (
          <>
            <Route path="/" component={DashboardPage} />
            <Route path="/find-buddies" component={FindBuddiesPage} />
            <Route path="/find-groups" component={FindGroupsPage} />
            <Route path="/create-group" component={CreateGroupPage} />
            <Route path="/profile" component={ProfilePage} />
            <Route path="/auth">
              <DashboardPage />
            </Route>
          </>
        ) : (
          <>
            {/* Routes for non-authenticated users */}
            <Route path="/auth" component={SimpleAuthPage} />
            <Route path="/">
              <SimpleAuthPage />
            </Route>
            <Route path="/find-buddies">
              <SimpleAuthPage />
            </Route>
            <Route path="/find-groups">
              <SimpleAuthPage />
            </Route>
            <Route path="/create-group">
              <SimpleAuthPage />
            </Route>
            <Route path="/profile">
              <SimpleAuthPage />
            </Route>
          </>
        )}
        
        {/* Common routes */}
        <Route component={NotFound} />
      </Switch>
      <Toaster />
    </>
  );
}
