import { useLocation } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Define the form schema
const createGroupSchema = z.object({
  name: z.string().min(3, "Group name must be at least 3 characters"),
  code: z.string().min(6, "Group code must be at least 6 characters"),
  topic: z.string().optional(),
});

type FormValues = z.infer<typeof createGroupSchema>;

export default function CreateGroupPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  // Initialize form
  const form = useForm<FormValues>({
    resolver: zodResolver(createGroupSchema),
    defaultValues: {
      name: "",
      code: generateRandomCode(),
      topic: "",
    },
  });
  
  // Generate a random code for the study group
  function generateRandomCode() {
    return Math.floor(1000000 + Math.random() * 9000000).toString();
  }
  
  // Handle form submission
  const onSubmit = async (values: FormValues) => {
    try {
      await apiRequest("POST", "/api/study-groups", values);
      toast({
        title: "Success!",
        description: "Study group created successfully.",
      });
      // Invalidate the queries to refresh the data
      queryClient.invalidateQueries({ queryKey: ["/api/user/study-groups"] });
      navigate("/");
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create study group. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  return (
    <div className="min-h-screen bg-background text-white flex flex-col">
      {/* Header */}
      <div className="flex items-center p-4 bg-gray-800">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => navigate("/")}
          className="mr-2 text-blue-500"
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold">Create Study Group</h1>
      </div>
      
      <div className="p-4 flex-1">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Group Name</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Enter a name for your study group" 
                      {...field} 
                      className="bg-gray-800 border-gray-700"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="code"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Group Code</FormLabel>
                  <div className="flex">
                    <FormControl>
                      <Input 
                        {...field} 
                        className="bg-gray-800 border-gray-700"
                        readOnly
                      />
                    </FormControl>
                    <Button 
                      type="button" 
                      variant="outline" 
                      className="ml-2"
                      onClick={() => form.setValue("code", generateRandomCode())}
                    >
                      Generate
                    </Button>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="topic"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Topic (Optional)</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="E.g., BMAT102L, Physics, Machine Learning" 
                      {...field} 
                      className="bg-gray-800 border-gray-700"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              className="w-full bg-primary hover:bg-primary/90 h-12 mt-6"
            >
              Create Study Group
            </Button>
          </form>
        </Form>
        
        <div className="mt-8 bg-gray-800 rounded-lg p-4">
          <h3 className="font-medium mb-2">About Study Groups</h3>
          <p className="text-gray-400 text-sm">
            Create a study group to collaborate with others. Share the group code with 
            friends or classmates so they can join. Groups level up as you study together!
          </p>
        </div>
      </div>
    </div>
  );
}
