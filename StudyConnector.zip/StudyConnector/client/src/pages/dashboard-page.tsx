import { useState } from "react";
import { Link, useLocation } from "wouter";
import Logo from "@/components/logo";
import StudyGroupList from "@/components/study-group-list";
import StudyBuddyList from "@/components/study-buddy-list";
import RecommendedGroups from "@/components/recommended-groups";
import RecommendedBuddies from "@/components/recommended-buddies";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  BookOpen, 
  Users, 
  Search, 
  UserCircle, 
  Trophy, 
  GraduationCap 
} from "lucide-react";

export default function DashboardPage() {
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("groups");

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black text-white flex flex-col">
      <div className="py-6 flex justify-center items-center bg-gradient-to-r from-purple-900 via-primary to-blue-900 border-b border-gray-800 shadow-xl">
        <div className="flex items-center gap-3">
          <Logo size={45} />
          <h1 className="text-2xl font-bold tracking-tight">StudyBuddy</h1>
        </div>
      </div>
      
      <div className="flex-1 px-4 md:px-8 pt-6 pb-20 flex flex-col max-w-5xl mx-auto w-full">
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <GraduationCap className="h-6 w-6 text-primary" />
          <span>Welcome to Your Learning Hub</span>
        </h2>
        
        {/* Quick Actions Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Button 
            variant="default" 
            className="h-20 bg-gradient-to-br from-purple-800 to-purple-900 hover:from-purple-700 hover:to-purple-800 border border-purple-700 shadow-md transition-all duration-300 flex flex-col items-center justify-center gap-1 p-2"
            onClick={() => navigate("/create-group")}
          >
            <BookOpen className="h-6 w-6" />
            <span>Create Group</span>
          </Button>
          <Button 
            variant="default" 
            className="h-20 bg-gradient-to-br from-blue-800 to-blue-900 hover:from-blue-700 hover:to-blue-800 border border-blue-700 shadow-md transition-all duration-300 flex flex-col items-center justify-center gap-1 p-2"
            onClick={() => navigate("/find-buddies")}
          >
            <Search className="h-6 w-6" />
            <span>Find Buddies</span>
          </Button>
          <Button 
            variant="default" 
            className="h-20 bg-gradient-to-br from-cyan-800 to-cyan-900 hover:from-cyan-700 hover:to-cyan-800 border border-cyan-700 shadow-md transition-all duration-300 flex flex-col items-center justify-center gap-1 p-2"
            onClick={() => navigate("/find-groups")}
          >
            <Users className="h-6 w-6" />
            <span>Find Groups</span>
          </Button>
          <Button 
            variant="default" 
            className="h-20 bg-gradient-to-br from-indigo-800 to-indigo-900 hover:from-indigo-700 hover:to-indigo-800 border border-indigo-700 shadow-md transition-all duration-300 flex flex-col items-center justify-center gap-1 p-2"
            onClick={() => navigate("/profile")}
          >
            <UserCircle className="h-6 w-6" />
            <span>Profile</span>
          </Button>
        </div>
        
        {/* Rankings Button */}
        <Button 
          className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-black font-bold mb-8 h-14 shadow-md transition-all duration-300 flex items-center justify-center gap-2"
        >
          <Trophy className="h-5 w-5" />
          <span className="text-lg">See the Rankings</span>
        </Button>
        
        {/* Recommendations Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="md:col-span-1">
            <RecommendedGroups />
          </div>
          <div className="md:col-span-1">
            <RecommendedBuddies />
          </div>
        </div>
        
        {/* Tabs for Groups and Buddies */}
        <Tabs defaultValue="groups" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6 bg-gray-800 p-1 shadow-md">
            <TabsTrigger 
              value="groups" 
              onClick={() => setActiveTab("groups")}
              className="data-[state=active]:bg-primary data-[state=active]:text-white"
            >
              <Users className="mr-2 h-4 w-4" />
              Your StudyGroups
            </TabsTrigger>
            <TabsTrigger 
              value="buddies" 
              onClick={() => setActiveTab("buddies")}
              className="data-[state=active]:bg-primary data-[state=active]:text-white"
            >
              <UserCircle className="mr-2 h-4 w-4" />
              Your StudyBuddies
            </TabsTrigger>
          </TabsList>
          <TabsContent value="groups">
            <StudyGroupList />
          </TabsContent>
          <TabsContent value="buddies">
            <StudyBuddyList />
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Footer */}
      <footer className="py-4 border-t border-gray-800 bg-gradient-to-r from-gray-900 to-black text-center text-gray-400 text-sm">
        <p>© 2025 StudyBuddy - Connect, Learn, and Grow Together</p>
      </footer>
    </div>
  );
}
