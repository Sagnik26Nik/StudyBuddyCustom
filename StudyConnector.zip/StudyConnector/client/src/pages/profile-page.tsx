import { useLocation } from "wouter";
import { ChevronLeft, LogOut, Calendar, Bell, Camera, Edit, Key } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useState, useEffect } from "react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

export default function ProfilePage() {
  const [, navigate] = useLocation();
  const [user, setUser] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const { toast } = useToast();
  
  useEffect(() => {
    async function fetchUser() {
      try {
        const res = await apiRequest("GET", "/api/user");
        if (res.ok) {
          const userData = await res.json();
          setUser(userData);
        } else {
          navigate("/auth");
        }
      } catch (error) {
        console.error("Error fetching user:", error);
        navigate("/auth");
      } finally {
        setIsLoading(false);
      }
    }
    
    fetchUser();
  }, [navigate]);
  
  const handleLogout = async () => {
    try {
      setIsLoggingOut(true);
      await apiRequest("POST", "/api/logout");
      queryClient.setQueryData(["/api/user"], null);
      navigate("/auth");
    } catch (error) {
      toast({
        title: "Logout failed",
        description: "Please try again",
        variant: "destructive",
      });
    } finally {
      setIsLoggingOut(false);
    }
  };
  
  if (isLoading || !user) {
    return (
      <div className="min-h-screen bg-background flex justify-center items-center">
        <div className="animate-pulse flex flex-col items-center">
          <div className="rounded-full bg-gray-700 h-16 w-16 mb-4"></div>
          <div className="h-4 bg-gray-700 rounded w-24 mb-2.5"></div>
          <div className="h-3 bg-gray-700 rounded w-16"></div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-background text-white flex flex-col">
      {/* Header */}
      <div className="flex items-center p-4 bg-gray-800">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => navigate("/")}
          className="mr-2 text-blue-500"
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold">Your Profile</h1>
      </div>
      
      <div className="p-4 flex-1">
        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="grid grid-cols-3 mb-6">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="chats">
              Chats
              <Badge className="ml-1 bg-primary text-white" variant="secondary">8</Badge>
            </TabsTrigger>
            <TabsTrigger value="schedule">Schedule</TabsTrigger>
          </TabsList>
          
          <TabsContent value="profile" className="mt-0">
            <Card className="bg-gray-800 border-none mb-6">
              <CardHeader className="flex flex-row items-center gap-4 pb-2">
                <div className="relative">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={user.avatarUrl || ''} />
                    <AvatarFallback className="bg-primary/20 text-primary text-xl">
                      {user.name?.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <Button 
                    size="icon" 
                    variant="outline" 
                    className="absolute -bottom-1 -right-1 h-7 w-7 rounded-full bg-primary text-white hover:bg-primary/90 border-background border-2"
                  >
                    <Camera className="h-3 w-3" />
                  </Button>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <CardTitle className="text-xl">{user.name}</CardTitle>
                    <Button variant="ghost" size="icon" className="h-6 w-6 text-gray-400 hover:text-white">
                      <Edit className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                  <p className="text-gray-400">@{user.username}</p>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <div className="bg-gray-700 rounded p-2">
                    <p className="text-gray-400 text-xs">Major</p>
                    <p className="font-medium">{user.major || "Not specified"}</p>
                  </div>
                  <div className="bg-gray-700 rounded p-2">
                    <p className="text-gray-400 text-xs">Study Streak</p>
                    <p className="font-medium">{user.streak || 0} days</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-800 border-none mb-6">
              <CardHeader>
                <CardTitle className="text-lg">Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div>
                  <p className="text-gray-400 text-xs">Email</p>
                  <p>{user.email}</p>
                </div>
                <Separator className="bg-gray-700" />
                <div>
                  <p className="text-gray-400 text-xs">Phone</p>
                  <p>{user.phone || "Not specified"}</p>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-800 border-none mb-6">
              <CardHeader>
                <CardTitle className="text-lg">Account Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button 
                  variant="outline" 
                  className="w-full justify-start text-gray-200"
                >
                  <Key className="h-4 w-4 mr-2 text-gray-400" />
                  Change Password
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start text-gray-200"
                >
                  <Bell className="h-4 w-4 mr-2 text-gray-400" />
                  Notification Settings
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start text-red-500 hover:text-red-400 hover:bg-red-950/30"
                  onClick={handleLogout}
                  disabled={isLoggingOut}
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  {isLoggingOut ? "Logging out..." : "Logout"}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="chats" className="mt-0">
            <ChatInterface user={user} />
          </TabsContent>
          
          <TabsContent value="schedule" className="mt-0">
            <ScheduleInterface user={user} />
          </TabsContent>
          
          <div className="text-center text-gray-500 text-xs mt-8">
            <p>StudyBuddy v1.0.0</p>
            <p>© 2025 StudyBuddy. All rights reserved.</p>
          </div>
        </Tabs>
      </div>
    </div>
  );
}

// Chat Interface Component
function ChatInterface({ user }: { user: any }) {
  const [activeChat, setActiveChat] = useState<number | null>(null);
  const [message, setMessage] = useState("");
  
  const sampleChats = [
    { 
      id: 1, 
      name: "Alex Johnson", 
      lastMessage: "When are we meeting for the study session?", 
      time: "10:30 AM",
      unread: 2,
      avatar: null,
      messages: [
        { id: 1, sender: "Alex", content: "Hey! How's your studying going?", time: "10:15 AM" },
        { id: 2, sender: "Alex", content: "I'm struggling with chapter 5", time: "10:20 AM" },
        { id: 3, sender: "Alex", content: "When are we meeting for the study session?", time: "10:30 AM" }
      ]
    },
    { 
      id: 2, 
      name: "Jamie Smith", 
      lastMessage: "Did you get the notes from yesterday?", 
      time: "Yesterday",
      unread: 0,
      avatar: null,
      messages: [
        { id: 1, sender: "Jamie", content: "Hey, did you attend yesterday's lecture?", time: "Yesterday" },
        { id: 2, sender: "You", content: "Yes, it was about quantum mechanics", time: "Yesterday" },
        { id: 3, sender: "Jamie", content: "Did you get the notes from yesterday?", time: "Yesterday" }
      ]
    },
    { 
      id: 3, 
      name: "Taylor Rodriguez", 
      lastMessage: "Thanks for helping me with that problem!", 
      time: "Yesterday",
      unread: 0,
      avatar: null,
      messages: [
        { id: 1, sender: "Taylor", content: "I'm stuck on this calculus problem", time: "Yesterday" },
        { id: 2, sender: "You", content: "Have you tried using the chain rule?", time: "Yesterday" },
        { id: 3, sender: "Taylor", content: "Thanks for helping me with that problem!", time: "Yesterday" }
      ]
    },
    { 
      id: 4, 
      name: "CS Study Circle", 
      lastMessage: "Jordan: I found a great resource for algorithms", 
      time: "2 days ago",
      unread: 6,
      avatar: null,
      isGroup: true,
      messages: [
        { id: 1, sender: "Alex", content: "Has anyone started the project?", time: "2 days ago" },
        { id: 2, sender: "Casey", content: "I'm working on the first part", time: "2 days ago" },
        { id: 3, sender: "Jordan", content: "I found a great resource for algorithms", time: "2 days ago" }
      ]
    },
  ];
  
  const sendMessage = () => {
    if (!message.trim() || !activeChat) return;
    // Here you would send the message to your API
    console.log("Sending message:", message, "to chat:", activeChat);
    setMessage("");
  };
  
  const activeConversation = sampleChats.find(chat => chat.id === activeChat);
  
  return (
    <div className="bg-gray-800 rounded-lg overflow-hidden flex h-[70vh]">
      {/* Chat List */}
      <div className="w-1/3 border-r border-gray-700">
        <div className="p-3 border-b border-gray-700">
          <h3 className="font-bold">Messages</h3>
        </div>
        <div className="overflow-y-auto h-[calc(70vh-50px)]">
          {sampleChats.map(chat => (
            <div 
              key={chat.id}
              className={`p-3 border-b border-gray-700 cursor-pointer hover:bg-gray-700 transition-colors ${activeChat === chat.id ? 'bg-gray-700' : ''}`}
              onClick={() => setActiveChat(chat.id)}
            >
              <div className="flex items-center">
                <Avatar className="h-10 w-10 mr-3">
                  <AvatarFallback className="bg-primary/20 text-primary">
                    {chat.name.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-baseline">
                    <h4 className="font-medium truncate">{chat.name}</h4>
                    <span className="text-xs text-gray-400">{chat.time}</span>
                  </div>
                  <p className="text-gray-400 text-sm truncate">{chat.lastMessage}</p>
                </div>
                {chat.unread > 0 && (
                  <Badge className="ml-2 bg-blue-500">{chat.unread}</Badge>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Chat Window */}
      <div className="flex-1 flex flex-col">
        {activeChat ? (
          <>
            <div className="p-3 border-b border-gray-700 flex items-center">
              <Avatar className="h-8 w-8 mr-3">
                <AvatarFallback className="bg-primary/20 text-primary">
                  {activeConversation?.name.substring(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-medium">{activeConversation?.name}</h3>
                <p className="text-xs text-gray-400">
                  {activeConversation?.isGroup ? "Group chat" : "Online"}
                </p>
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {activeConversation?.messages.map(msg => (
                <div 
                  key={msg.id} 
                  className={`flex ${msg.sender === "You" ? "justify-end" : "justify-start"}`}
                >
                  <div 
                    className={`max-w-[70%] rounded-lg px-4 py-2 ${
                      msg.sender === "You" 
                        ? "bg-blue-600 text-white rounded-br-none" 
                        : "bg-gray-700 text-white rounded-bl-none"
                    }`}
                  >
                    {activeConversation.isGroup && msg.sender !== "You" && (
                      <p className="text-xs font-medium text-blue-300">{msg.sender}</p>
                    )}
                    <p>{msg.content}</p>
                    <p className="text-xs text-gray-300 text-right mt-1">{msg.time}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="p-3 border-t border-gray-700 flex">
              <input
                type="text"
                className="flex-1 bg-gray-700 border-none rounded-l-md px-3 py-2 focus:outline-none"
                placeholder="Type a message..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendMessage()}
              />
              <Button 
                className="rounded-l-none"
                onClick={sendMessage}
              >
                Send
              </Button>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-400">
            Select a chat to start messaging
          </div>
        )}
      </div>
    </div>
  );
}

// Schedule Interface Component
function ScheduleInterface({ user }: { user: any }) {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showEventForm, setShowEventForm] = useState(false);
  const [eventTitle, setEventTitle] = useState("");
  const [eventTime, setEventTime] = useState("12:00");
  const [eventDuration, setEventDuration] = useState("60");
  const [eventType, setEventType] = useState("study");
  
  const weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const months = ["January", "February", "March", "April", "May", "June", 
                  "July", "August", "September", "October", "November", "December"];
  
  // Generate dates for the calendar view
  const generateCalendarDays = () => {
    const today = new Date();
    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();
    
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
    
    const days = [];
    
    // Add dates from previous month to fill the first row
    const prevMonthDays = new Date(currentYear, currentMonth, 0).getDate();
    for (let i = firstDayOfMonth - 1; i >= 0; i--) {
      days.push({
        date: new Date(currentYear, currentMonth - 1, prevMonthDays - i),
        isCurrentMonth: false
      });
    }
    
    // Add dates from current month
    for (let i = 1; i <= daysInMonth; i++) {
      days.push({
        date: new Date(currentYear, currentMonth, i),
        isCurrentMonth: true,
        isToday: i === today.getDate() && 
                 currentMonth === today.getMonth() && 
                 currentYear === today.getFullYear()
      });
    }
    
    // Add dates from next month to complete the grid
    const remainingDays = 42 - days.length; // 6 rows x 7 days = 42
    for (let i = 1; i <= remainingDays; i++) {
      days.push({
        date: new Date(currentYear, currentMonth + 1, i),
        isCurrentMonth: false
      });
    }
    
    return days;
  };
  
  // Sample scheduled events
  const sampleEvents = [
    {
      id: 1,
      title: "CS Study Group",
      date: new Date(),
      startTime: "14:00",
      duration: 90,
      type: "group", // group, buddy, personal
      participants: ["Alex", "Jamie", "Taylor"]
    },
    {
      id: 2,
      title: "Math Tutoring with Jamie",
      date: new Date(),
      startTime: "16:30",
      duration: 60,
      type: "buddy",
      participants: ["Jamie"]
    },
    {
      id: 3,
      title: "Personal Study - Physics",
      date: new Date(new Date().setDate(new Date().getDate() + 1)),
      startTime: "10:00",
      duration: 120,
      type: "personal",
      participants: []
    }
  ];
  
  const calendarDays = generateCalendarDays();
  
  // Filter events for the selected date
  const dayEvents = sampleEvents.filter(event => 
    event.date.toDateString() === selectedDate.toDateString()
  );
  
  const handleCreateEvent = () => {
    // Here you would send the event to your API
    console.log("Creating event:", {
      title: eventTitle,
      date: selectedDate,
      startTime: eventTime,
      duration: parseInt(eventDuration),
      type: eventType
    });
    
    // Reset form and hide it
    setEventTitle("");
    setEventTime("12:00");
    setEventDuration("60");
    setEventType("study");
    setShowEventForm(false);
  };
  
  return (
    <div>
      {/* Calendar View */}
      <Card className="bg-gray-800 border-none mb-6">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg">
              {months[selectedDate.getMonth()]} {selectedDate.getFullYear()}
            </CardTitle>
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setSelectedDate(new Date())}
              >
                Today
              </Button>
              <Button 
                variant="outline" 
                size="icon" 
                className="h-8 w-8"
                onClick={() => {
                  const prevMonth = new Date(selectedDate);
                  prevMonth.setMonth(prevMonth.getMonth() - 1);
                  setSelectedDate(prevMonth);
                }}
              >
                &lt;
              </Button>
              <Button 
                variant="outline" 
                size="icon" 
                className="h-8 w-8"
                onClick={() => {
                  const nextMonth = new Date(selectedDate);
                  nextMonth.setMonth(nextMonth.getMonth() + 1);
                  setSelectedDate(nextMonth);
                }}
              >
                &gt;
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Weekday Headers */}
          <div className="grid grid-cols-7 gap-1 mb-2">
            {weekdays.map(day => (
              <div key={day} className="text-center text-gray-400 text-sm py-1">
                {day}
              </div>
            ))}
          </div>
          
          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-1">
            {calendarDays.map((day, index) => (
              <div 
                key={index} 
                className={`
                  aspect-square p-1 text-sm border border-gray-700 rounded
                  ${day.isCurrentMonth ? 'bg-gray-700' : 'bg-gray-800 text-gray-500'}
                  ${day.isToday ? 'bg-blue-900/30 border-blue-500' : ''}
                  ${day.date.toDateString() === selectedDate.toDateString() ? 'ring-2 ring-primary' : ''}
                  hover:bg-gray-600 cursor-pointer
                `}
                onClick={() => setSelectedDate(day.date)}
              >
                <div className="font-medium">
                  {day.date.getDate()}
                </div>
                {/* Event indicators */}
                {sampleEvents.filter(event => 
                  event.date.toDateString() === day.date.toDateString()
                ).slice(0, 2).map((event, i) => (
                  <div 
                    key={i} 
                    className={`
                      mt-1 h-1 rounded-full
                      ${event.type === 'group' ? 'bg-green-500' : ''}
                      ${event.type === 'buddy' ? 'bg-blue-500' : ''}
                      ${event.type === 'personal' ? 'bg-purple-500' : ''}
                    `}
                  ></div>
                ))}
                {sampleEvents.filter(event => 
                  event.date.toDateString() === day.date.toDateString()
                ).length > 2 && (
                  <div className="text-xs text-gray-400 mt-1">
                    +{sampleEvents.filter(event => 
                      event.date.toDateString() === day.date.toDateString()
                    ).length - 2} more
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {/* Events for Selected Day */}
      <Card className="bg-gray-800 border-none mb-6">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg">
              {selectedDate.toDateString() === new Date().toDateString() 
                ? "Today's Schedule" 
                : `Schedule for ${selectedDate.toDateString()}`}
            </CardTitle>
            <Button onClick={() => setShowEventForm(!showEventForm)}>
              {showEventForm ? "Cancel" : "Add Event"}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Event Creation Form */}
          {showEventForm && (
            <div className="bg-gray-700 p-4 rounded-lg mb-4 space-y-4">
              <h3 className="font-medium">Create New Event</h3>
              <div className="space-y-2">
                <label className="text-sm text-gray-300">Event Title</label>
                <input
                  type="text"
                  className="w-full bg-gray-800 border border-gray-600 rounded px-3 py-2"
                  value={eventTitle}
                  onChange={(e) => setEventTitle(e.target.value)}
                  placeholder="e.g., Study for Chemistry Exam"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm text-gray-300">Time</label>
                  <input
                    type="time"
                    className="w-full bg-gray-800 border border-gray-600 rounded px-3 py-2"
                    value={eventTime}
                    onChange={(e) => setEventTime(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm text-gray-300">Duration (minutes)</label>
                  <select
                    className="w-full bg-gray-800 border border-gray-600 rounded px-3 py-2"
                    value={eventDuration}
                    onChange={(e) => setEventDuration(e.target.value)}
                  >
                    <option value="30">30 minutes</option>
                    <option value="60">1 hour</option>
                    <option value="90">1.5 hours</option>
                    <option value="120">2 hours</option>
                    <option value="180">3 hours</option>
                  </select>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm text-gray-300">Event Type</label>
                <div className="flex space-x-2">
                  <button
                    className={`px-3 py-1 rounded ${eventType === 'study' ? 'bg-purple-500 text-white' : 'bg-gray-600'}`}
                    onClick={() => setEventType('study')}
                  >
                    Personal Study
                  </button>
                  <button
                    className={`px-3 py-1 rounded ${eventType === 'buddy' ? 'bg-blue-500 text-white' : 'bg-gray-600'}`}
                    onClick={() => setEventType('buddy')}
                  >
                    Study Buddy
                  </button>
                  <button
                    className={`px-3 py-1 rounded ${eventType === 'group' ? 'bg-green-500 text-white' : 'bg-gray-600'}`}
                    onClick={() => setEventType('group')}
                  >
                    Study Group
                  </button>
                </div>
              </div>
              <Button 
                className="w-full" 
                onClick={handleCreateEvent}
                disabled={!eventTitle.trim()}
              >
                Create Event
              </Button>
            </div>
          )}
          
          {/* List of Events */}
          {dayEvents.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              No events scheduled for this day
            </div>
          ) : (
            <div className="space-y-3">
              {dayEvents.map(event => (
                <div 
                  key={event.id} 
                  className={`
                    p-3 rounded-lg border-l-4
                    ${event.type === 'group' ? 'border-green-500 bg-green-900/20' : ''}
                    ${event.type === 'buddy' ? 'border-blue-500 bg-blue-900/20' : ''}
                    ${event.type === 'personal' ? 'border-purple-500 bg-purple-900/20' : ''}
                  `}
                >
                  <div className="flex justify-between">
                    <h4 className="font-medium">{event.title}</h4>
                    <Badge 
                      variant="outline" 
                      className={`
                        ${event.type === 'group' ? 'border-green-500 text-green-500' : ''}
                        ${event.type === 'buddy' ? 'border-blue-500 text-blue-500' : ''}
                        ${event.type === 'personal' ? 'border-purple-500 text-purple-500' : ''}
                      `}
                    >
                      {event.type === 'group' ? 'Group' : ''}
                      {event.type === 'buddy' ? 'Buddy' : ''}
                      {event.type === 'personal' ? 'Personal' : ''}
                    </Badge>
                  </div>
                  <div className="flex items-center mt-2">
                    <Calendar className="h-4 w-4 mr-2 text-gray-400" />
                    <span className="text-gray-300">
                      {event.startTime} · {event.duration} min
                    </span>
                  </div>
                  {event.participants.length > 0 && (
                    <div className="mt-2 flex items-center">
                      <div className="flex -space-x-2 mr-2">
                        {event.participants.slice(0, 3).map((participant, i) => (
                          <Avatar key={i} className="h-6 w-6 border border-background">
                            <AvatarFallback className="text-xs bg-primary/20 text-primary">
                              {participant.substring(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                        ))}
                      </div>
                      <span className="text-sm text-gray-400">
                        {event.participants.join(', ')}
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
