import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, Search, QrCode } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface StudyGroup {
  id: number;
  name: string;
  code: string;
  topic?: string;
  memberCount: number;
  level: number;
}

export default function FindGroupsPage() {
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  
  // Get all study groups
  const { data: studyGroups, isLoading } = useQuery<StudyGroup[]>({
    queryKey: ["/api/study-groups"],
  });
  
  // Join a study group
  const joinGroup = async (code: string) => {
    try {
      await apiRequest("POST", `/api/study-groups/${code}/join`, {});
      toast({
        title: "Success!",
        description: "You have joined the study group.",
      });
      // Invalidate the queries to refresh the data
      queryClient.invalidateQueries({ queryKey: ["/api/study-groups"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/study-groups"] });
      navigate("/");
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to join the study group. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  // Filter groups based on search query
  const filteredGroups = studyGroups 
    ? studyGroups.filter(group => 
      group.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      group.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (group.topic && group.topic.toLowerCase().includes(searchQuery.toLowerCase()))
    )
    : [];
  
  return (
    <div className="min-h-screen bg-background text-white flex flex-col">
      {/* Header */}
      <div className="flex items-center p-4 bg-gray-800">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => navigate("/")}
          className="mr-2 text-blue-500"
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold">Find Study Groups</h1>
      </div>
      
      <div className="p-4 flex-1">
        {/* Search Bar with QR Code Scanner */}
        <div className="flex mb-6">
          <div className="relative flex-1 mr-2">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input 
              type="search"
              placeholder="Study Group Code"
              className="pl-10 bg-gray-800 border-none"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button 
            variant="outline" 
            size="icon"
            className="bg-gray-800 hover:bg-gray-700"
          >
            <QrCode className="h-5 w-5 text-blue-500" />
          </Button>
        </div>
        
        {/* Suggested Groups */}
        <h2 className="text-xl font-bold mb-4">Suggested</h2>
        
        {isLoading ? (
          <div className="space-y-3">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="bg-gray-800 rounded-lg p-4 flex items-center animate-pulse">
                <div className="flex-1">
                  <div className="h-5 bg-gray-700 rounded w-1/3 mb-2"></div>
                  <div className="h-4 bg-gray-700 rounded w-2/3 mb-1"></div>
                  <div className="h-4 bg-gray-700 rounded w-1/2"></div>
                </div>
                <div className="flex flex-col items-end">
                  <div className="h-5 bg-gray-700 rounded w-8 mb-2"></div>
                  <div className="h-8 bg-gray-700 rounded w-16"></div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {filteredGroups.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                {searchQuery 
                  ? "No groups found matching your search" 
                  : "No study groups available"}
              </div>
            ) : (
              filteredGroups.map((group) => (
                <div key={group.id} className="bg-gray-800 rounded-lg p-4 flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="font-medium text-lg">{group.code}</h3>
                    {group.topic && <p className="text-gray-400 text-sm">Topic: {group.topic}</p>}
                    <p className="text-gray-400 text-sm">Members: {group.memberCount}</p>
                  </div>
                  <div className="flex flex-col items-end">
                    <div className="text-primary font-medium mb-2">{group.level}</div>
                    <Button 
                      size="sm"
                      className="bg-primary hover:bg-primary/90"
                      onClick={() => joinGroup(group.code)}
                    >
                      Join
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
