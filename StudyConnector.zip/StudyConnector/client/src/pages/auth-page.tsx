import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Logo from "@/components/logo";

// Define the form schema for login
const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(1, "Password is required"),
});

// Define the form schema for registration
const registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().min(10, "Please enter a valid phone number"),
  major: z.string().min(2, "Field of study is required"),
  password: z.string().min(8, "Password must be at least 8 characters"),
  confirmPassword: z.string().min(8, "Please confirm your password"),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const { toast } = useToast();

  // Initialize login form
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  // Initialize registration form
  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      name: "",
      email: "",
      phone: "",
      major: "",
      password: "",
      confirmPassword: "",
    },
  });

  // Handle login form submission
  const onLoginSubmit = async (values: LoginFormValues) => {
    try {
      setIsLoggingIn(true);
      const res = await apiRequest("POST", "/api/login", values);
      const user = await res.json();
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Login successful",
        description: `Welcome back, ${user.name}!`,
      });
      window.location.href = "/";
    } catch (error) {
      toast({
        title: "Login failed",
        description: error instanceof Error ? error.message : "Please check your credentials",
        variant: "destructive",
      });
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Handle registration form submission
  const onRegisterSubmit = async (values: RegisterFormValues) => {
    try {
      setIsRegistering(true);
      // Remove confirmPassword as it's not needed in the API
      const { confirmPassword, ...credentials } = values;
      const res = await apiRequest("POST", "/api/register", credentials);
      const user = await res.json();
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Registration successful",
        description: `Welcome to StudyBuddy, ${user.name}!`,
      });
      window.location.href = "/";
    } catch (error) {
      toast({
        title: "Registration failed",
        description: error instanceof Error ? error.message : "Please check your information",
        variant: "destructive",
      });
    } finally {
      setIsRegistering(false);
    }
  };

  // Welcome screen illustration component
  const WelcomeIllustration = () => (
    <div className="relative flex items-center justify-center w-full h-full">
      <div className="relative flex flex-col items-center">
        {/* Stack of books with people studying */}
        <div className="w-full h-60 relative mb-8">
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-4/5">
            <div className="relative flex flex-col items-center">
              {/* Books */}
              <div className="w-16 h-6 bg-yellow-500 rounded-sm mb-1 ml-8 transform -rotate-12"></div>
              <div className="w-20 h-6 bg-pink-500 rounded-sm mb-1 transform rotate-6"></div>
              <div className="w-16 h-6 bg-blue-500 rounded-sm mb-1 ml-4 transform -rotate-3"></div>
              <div className="w-20 h-6 bg-green-400 rounded-sm mb-1 -ml-6 transform rotate-12"></div>
              <div className="w-24 h-6 bg-yellow-600 rounded-sm"></div>
              
              {/* Person 1 */}
              <div className="absolute bottom-10 -left-8 flex flex-col items-center">
                <div className="w-8 h-8 bg-pink-400 rounded-full mb-1"></div>
                <div className="w-10 h-12 bg-teal-400 rounded-md"></div>
                <div className="w-8 h-2 bg-pink-600 rounded-md mt-1"></div>
              </div>

              {/* Person 2 */}
              <div className="absolute bottom-16 right-2 flex flex-col items-center">
                <div className="w-8 h-8 bg-blue-400 rounded-full mb-1"></div>
                <div className="w-10 h-12 bg-pink-500 rounded-md"></div>
                <div className="w-8 h-2 bg-blue-600 rounded-md mt-1"></div>
              </div>

              {/* Stars */}
              <div className="absolute top-0 left-0 text-yellow-400 text-xl">✦</div>
              <div className="absolute top-10 right-0 text-pink-400 text-xl">✦</div>
              <div className="absolute bottom-20 left-10 text-teal-400 text-xl">✦</div>
              <div className="absolute bottom-8 right-8 text-pink-400 text-xl">✦</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row">
      {/* Auth Form Section */}
      <div className="flex-1 flex flex-col p-6 md:p-10 md:justify-center">
        <div className="flex flex-col items-center md:items-start mb-8">
          <Logo size={40} />
        </div>

        {isLogin ? (
          // Login Form
          <div className="w-full max-w-md mx-auto">
            <h1 className="text-3xl font-bold mb-1">LogIn</h1>
            <p className="text-gray-400 mb-8">Welcome back you've been missed!</p>
            
            <Form {...loginForm}>
              <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                <FormField
                  control={loginForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Your email address" 
                          {...field} 
                          className="bg-gray-800 border-gray-700"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={loginForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input 
                          type="password" 
                          placeholder="Your password" 
                          {...field} 
                          className="bg-gray-800 border-primary"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="text-right">
                  <a 
                    href="#" 
                    className="text-gray-400 text-sm hover:text-blue-500"
                    onClick={(e) => e.preventDefault()}
                  >
                    trouble getting in? <span className="text-white font-medium">Reset Password</span>
                  </a>
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full bg-white text-black hover:bg-gray-200 h-12 mt-4"
                  disabled={isLoggingIn}
                >
                  {isLoggingIn ? "Logging in..." : "LogIn"}
                </Button>
                
                <p className="text-center mt-6">
                  Don't have an account?{" "}
                  <button 
                    type="button"
                    onClick={() => setIsLogin(false)} 
                    className="text-blue-500 font-medium hover:underline"
                  >
                    SignUp
                  </button>
                </p>
              </form>
            </Form>
          </div>
        ) : (
          // Registration Form
          <div className="w-full max-w-md mx-auto">
            <h1 className="text-3xl font-bold mb-1">SignUp</h1>
            <p className="text-gray-400 mb-8">Create an account it's freeeeee!</p>
            
            <Form {...registerForm}>
              <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                <FormField
                  control={registerForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Your full name" 
                          {...field} 
                          className="bg-gray-800 border-primary"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={registerForm.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Choose a username" 
                          {...field} 
                          className="bg-gray-800 border-gray-700"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={registerForm.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Your phone number" 
                          {...field} 
                          className="bg-gray-800 border-gray-700"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={registerForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Your email address" 
                          {...field} 
                          className="bg-gray-800 border-gray-700"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={registerForm.control}
                  name="major"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Field of Study/Major</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Your field of study" 
                          {...field} 
                          className="bg-gray-800 border-gray-700"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={registerForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input 
                          type="password" 
                          placeholder="Create a strong password" 
                          {...field} 
                          className="bg-gray-800 border-gray-700"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={registerForm.control}
                  name="confirmPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Confirm Password</FormLabel>
                      <FormControl>
                        <Input 
                          type="password" 
                          placeholder="Confirm your password" 
                          {...field} 
                          className="bg-gray-800 border-gray-700"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  className="w-full bg-white text-black hover:bg-gray-200 h-12 mt-4"
                  disabled={isRegistering}
                >
                  {isRegistering ? "Creating Account..." : "Create Account"}
                </Button>
                
                <p className="text-center mt-6">
                  Already have an account?{" "}
                  <button 
                    type="button"
                    onClick={() => setIsLogin(true)} 
                    className="text-blue-500 font-medium hover:underline"
                  >
                    Login
                  </button>
                </p>
              </form>
            </Form>
          </div>
        )}
      </div>
      
      {/* Welcome Illustration Section - Hidden on Mobile */}
      <div className="hidden md:flex md:flex-1 bg-background flex-col items-center justify-center p-10">
        <div className="max-w-md mx-auto flex flex-col items-center">
          <div className="mb-8">
            <Logo size={60} />
          </div>
          
          <WelcomeIllustration />
          
          <h2 className="text-2xl font-bold text-center mb-6">
            Experience a whole new way of doing group study!
          </h2>
        </div>
      </div>
    </div>
  );
}
