import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, Plus, Search } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface User {
  id: number;
  name: string;
  major: string;
  avatarUrl: string | null;
}

interface PendingRequest {
  id: number;
  userId: number;
  status: string;
  user: User;
}

export default function FindBuddiesPage() {
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  
  // Get suggested buddies (all users for simplicity)
  const { data: suggestedBuddies, isLoading } = useQuery<User[]>({
    queryKey: ["/api/users/search"],
  });
  
  // Get pending requests
  const { data: pendingRequests } = useQuery<PendingRequest[]>({
    queryKey: ["/api/user/buddy-requests"],
  });
  
  // Send buddy request
  const sendBuddyRequest = async (buddyId: number) => {
    try {
      await apiRequest("POST", "/api/user/buddy-request", { buddyId });
      toast({
        title: "Request sent!",
        description: "Buddy request has been sent successfully.",
      });
      // Invalidate the queries to refresh the data
      queryClient.invalidateQueries({ queryKey: ["/api/user/buddy-requests"] });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send buddy request. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  // Filter users based on search query
  const filteredBuddies = suggestedBuddies 
    ? suggestedBuddies.filter(buddy => 
      buddy.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      buddy.major.toLowerCase().includes(searchQuery.toLowerCase())
    )
    : [];
  
  return (
    <div className="min-h-screen bg-background text-white flex flex-col">
      {/* Header */}
      <div className="flex items-center p-4 bg-gray-800">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => navigate("/")}
          className="mr-2 text-blue-500"
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-xl font-bold">Find Study Buddies</h1>
      </div>
      
      <div className="p-4 flex-1">
        {/* Search Bar */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Input 
            type="search"
            placeholder="Find your Buddies"
            className="pl-10 bg-gray-800 border-none"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        {/* Pending Requests */}
        <Button 
          variant="outline" 
          className="w-full bg-white text-black hover:bg-gray-200 justify-between mb-6 py-5"
          onClick={() => navigate("/pending-requests")}
        >
          <span className="font-medium">Pending Requests</span>
          <div className="flex items-center">
            <span className="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center mr-2">
              {pendingRequests?.length || 0}
            </span>
            <ChevronRight className="h-4 w-4" />
          </div>
        </Button>
        
        {/* Suggested Buddies */}
        <h2 className="text-xl font-bold mb-4">Suggested</h2>
        
        {isLoading ? (
          <div className="space-y-3">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="bg-gray-800 rounded-lg p-3 flex items-center animate-pulse">
                <div className="w-12 h-12 rounded-full bg-gray-700 mr-4"></div>
                <div className="flex-1">
                  <div className="h-5 bg-gray-700 rounded w-1/3 mb-2"></div>
                  <div className="h-4 bg-gray-700 rounded w-2/3"></div>
                </div>
                <div className="w-10 h-10 rounded-full bg-gray-700"></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {filteredBuddies.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                {searchQuery 
                  ? "No buddies found matching your search" 
                  : "No suggested buddies available"}
              </div>
            ) : (
              filteredBuddies.map((buddy) => (
                <div key={buddy.id} className="bg-gray-800 rounded-lg p-3 flex items-center">
                  <Avatar className="mr-4 h-12 w-12">
                    <AvatarImage src={buddy.avatarUrl || ''} />
                    <AvatarFallback className="bg-primary/20 text-primary">
                      {buddy.name.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h3 className="font-medium">{buddy.name}</h3>
                    <p className="text-gray-400 text-sm">Major: {buddy.major}</p>
                  </div>
                  <Button 
                    size="icon"
                    className="w-10 h-10 rounded-full bg-primary hover:bg-primary/90"
                    onClick={() => sendBuddyRequest(buddy.id)}
                  >
                    <Plus className="h-5 w-5" />
                  </Button>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
