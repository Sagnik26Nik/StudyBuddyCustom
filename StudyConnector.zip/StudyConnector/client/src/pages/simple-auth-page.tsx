import { useState } from "react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Logo from "@/components/logo";
import { Button } from "@/components/ui/button";

export default function SimpleAuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  // Login form state
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // Register form state
  const [username, setUsername] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [major, setMajor] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setIsLoading(true);
      
      const response = await fetch("/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
        credentials: "include"
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Login failed");
      }
      
      const user = await response.json();
      console.log("Login successful, user data:", user);
      
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Login successful",
        description: `Welcome back, ${user.name}!`,
      });
      
      // Use window.location.replace to force a full page reload
      window.location.replace("/");
    } catch (error) {
      console.error("Login error:", error);
      toast({
        title: "Login failed",
        description: error instanceof Error ? error.message : "Please check your credentials",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      toast({
        title: "Passwords don't match",
        description: "Please make sure your passwords match",
        variant: "destructive",
      });
      return;
    }
    
    try {
      setIsLoading(true);
      const userData = { username, name, email, phone, major, password };
      
      const response = await fetch("/api/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(userData),
        credentials: "include"
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Registration failed");
      }
      
      const user = await response.json();
      console.log("Registration successful, user data:", user);
      
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Registration successful",
        description: `Welcome to StudyBuddy, ${user.name}!`,
      });
      
      // Use window.location.replace to force a full page reload
      window.location.replace("/");
    } catch (error) {
      console.error("Registration error:", error);
      toast({
        title: "Registration failed",
        description: error instanceof Error ? error.message : "Please check your information",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Welcome screen illustration component
  const WelcomeIllustration = () => (
    <div className="relative flex items-center justify-center w-full h-full">
      <div className="relative flex flex-col items-center">
        {/* Stack of books with people studying */}
        <div className="w-full h-60 relative mb-8">
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-4/5">
            <div className="relative flex flex-col items-center">
              {/* Books */}
              <div className="w-16 h-6 bg-yellow-500 rounded-sm mb-1 ml-8 transform -rotate-12"></div>
              <div className="w-20 h-6 bg-pink-500 rounded-sm mb-1 transform rotate-6"></div>
              <div className="w-16 h-6 bg-blue-500 rounded-sm mb-1 ml-4 transform -rotate-3"></div>
              <div className="w-20 h-6 bg-green-400 rounded-sm mb-1 -ml-6 transform rotate-12"></div>
              <div className="w-24 h-6 bg-yellow-600 rounded-sm"></div>
              
              {/* Person 1 */}
              <div className="absolute bottom-10 -left-8 flex flex-col items-center">
                <div className="w-8 h-8 bg-pink-400 rounded-full mb-1"></div>
                <div className="w-10 h-12 bg-teal-400 rounded-md"></div>
                <div className="w-8 h-2 bg-pink-600 rounded-md mt-1"></div>
              </div>

              {/* Person 2 */}
              <div className="absolute bottom-16 right-2 flex flex-col items-center">
                <div className="w-8 h-8 bg-blue-400 rounded-full mb-1"></div>
                <div className="w-10 h-12 bg-pink-500 rounded-md"></div>
                <div className="w-8 h-2 bg-blue-600 rounded-md mt-1"></div>
              </div>

              {/* Stars */}
              <div className="absolute top-0 left-0 text-yellow-400 text-xl">✦</div>
              <div className="absolute top-10 right-0 text-pink-400 text-xl">✦</div>
              <div className="absolute bottom-20 left-10 text-teal-400 text-xl">✦</div>
              <div className="absolute bottom-8 right-8 text-pink-400 text-xl">✦</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row">
      {/* Auth Form Section */}
      <div className="flex-1 flex flex-col p-6 md:p-10 md:justify-center">
        <div className="flex flex-col items-center md:items-start mb-8">
          <Logo size={40} />
        </div>

        {isLogin ? (
          // Login Form
          <div className="w-full max-w-md mx-auto">
            <h1 className="text-3xl font-bold mb-1">LogIn</h1>
            <p className="text-gray-400 mb-8">Welcome back you've been missed!</p>
            
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                  Email
                </label>
                <input
                  type="email"
                  className="flex h-10 w-full rounded-md border border-gray-700 bg-gray-800 px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-600"
                  placeholder="Your email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                  Password
                </label>
                <input
                  type="password"
                  className="flex h-10 w-full rounded-md border border-primary bg-gray-800 px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-600"
                  placeholder="Your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              
              <div className="text-right">
                <a 
                  href="#" 
                  className="text-gray-400 text-sm hover:text-blue-500"
                  onClick={(e) => e.preventDefault()}
                >
                  trouble getting in? <span className="text-white font-medium">Reset Password</span>
                </a>
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-white text-black hover:bg-gray-200 h-12 mt-4"
                disabled={isLoading}
              >
                {isLoading ? "Logging in..." : "LogIn"}
              </Button>
              
              <p className="text-center mt-6">
                Don't have an account?{" "}
                <button 
                  type="button"
                  onClick={() => setIsLogin(false)} 
                  className="text-blue-500 font-medium hover:underline"
                >
                  SignUp
                </button>
              </p>
            </form>
          </div>
        ) : (
          // Registration Form
          <div className="w-full max-w-md mx-auto">
            <h1 className="text-3xl font-bold mb-1">SignUp</h1>
            <p className="text-gray-400 mb-8">Create an account it's freeeeee!</p>
            
            <form onSubmit={handleRegister} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                  Name
                </label>
                <input
                  type="text"
                  className="flex h-10 w-full rounded-md border border-primary bg-gray-800 px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-600"
                  placeholder="Your full name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                  Username
                </label>
                <input
                  type="text"
                  className="flex h-10 w-full rounded-md border border-gray-700 bg-gray-800 px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-600"
                  placeholder="Choose a username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                  Phone Number
                </label>
                <input
                  type="tel"
                  className="flex h-10 w-full rounded-md border border-gray-700 bg-gray-800 px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-600"
                  placeholder="Your phone number"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                  Email
                </label>
                <input
                  type="email"
                  className="flex h-10 w-full rounded-md border border-gray-700 bg-gray-800 px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-600"
                  placeholder="Your email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                  Field of Study/Major
                </label>
                <input
                  type="text"
                  className="flex h-10 w-full rounded-md border border-gray-700 bg-gray-800 px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-600"
                  placeholder="Your field of study"
                  value={major}
                  onChange={(e) => setMajor(e.target.value)}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                  Password
                </label>
                <input
                  type="password"
                  className="flex h-10 w-full rounded-md border border-gray-700 bg-gray-800 px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-600"
                  placeholder="Create a strong password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                  Confirm Password
                </label>
                <input
                  type="password"
                  className="flex h-10 w-full rounded-md border border-gray-700 bg-gray-800 px-3 py-2 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-600"
                  placeholder="Confirm your password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-white text-black hover:bg-gray-200 h-12 mt-4"
                disabled={isLoading}
              >
                {isLoading ? "Creating Account..." : "Create Account"}
              </Button>
              
              <p className="text-center mt-6">
                Already have an account?{" "}
                <button 
                  type="button"
                  onClick={() => setIsLogin(true)} 
                  className="text-blue-500 font-medium hover:underline"
                >
                  Login
                </button>
              </p>
            </form>
          </div>
        )}
      </div>
      
      {/* Welcome Illustration Section - Hidden on Mobile */}
      <div className="hidden md:flex md:flex-1 bg-background flex-col items-center justify-center p-10">
        <div className="max-w-md mx-auto flex flex-col items-center">
          <div className="mb-8">
            <Logo size={60} />
          </div>
          
          <WelcomeIllustration />
          
          <h2 className="text-2xl font-bold text-center mb-6">
            Experience a whole new way of doing group study!
          </h2>
        </div>
      </div>
    </div>
  );
}