export default function Logo({ size = 40 }: { size?: number }) {
  return (
    <div className="animate-pulse drop-shadow-[0_0_8px_rgba(255,107,0,0.5)]">
      <svg 
        width={size} 
        height={size} 
        viewBox="0 0 80 80" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
      >
        <g>
          <circle cx="40" cy="30" r="10" fill="#FF6B00" />
          <path d="M20 45C25 35 30 50 40 50C50 50 55 35 60 45" stroke="#FF6B00" strokeWidth="8" strokeLinecap="round" />
          <path d="M20 45L10 35" stroke="#FF6B00" strokeWidth="8" strokeLinecap="round" />
          <path d="M60 45L70 35" stroke="#FF6B00" strokeWidth="8" strokeLinecap="round" />
        </g>
      </svg>
    </div>
  );
}
