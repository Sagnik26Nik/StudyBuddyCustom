import { useQuery } from "@tanstack/react-query";
import { Layers } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface StudyGroup {
  id: number;
  name: string;
  code: string;
  topic?: string;
  memberCount: number;
  level: number;
}

export default function StudyGroupList() {
  const { data: groups, isLoading } = useQuery<StudyGroup[]>({
    queryKey: ["/api/user/study-groups"],
  });

  if (isLoading) {
    return (
      <div className="mb-6">
        <h2 className="text-xl font-bold mb-4">Your StudyGroups</h2>
        <div className="flex space-x-4 overflow-x-auto pb-4">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="bg-gray-800 rounded-lg p-4 min-w-[180px]">
              <div className="flex justify-between items-start mb-2">
                <Skeleton className="h-6 w-6" />
                <Skeleton className="h-6 w-8" />
              </div>
              <Skeleton className="h-5 w-24 mt-8 mb-1" />
              <Skeleton className="h-4 w-32" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!groups || groups.length === 0) {
    return (
      <div className="mb-6">
        <h2 className="text-xl font-bold mb-4">Your StudyGroups</h2>
        <div className="bg-gray-800 rounded-lg p-4 text-center">
          <p className="text-gray-400">You don't have any study groups yet.</p>
          <p className="text-gray-400">Create or join a study group to get started!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mb-6">
      <h2 className="text-xl font-bold mb-4">Your StudyGroups</h2>
      <div className="flex space-x-4 overflow-x-auto pb-4">
        {groups.map((group) => (
          <div key={group.id} className="bg-gray-800 rounded-lg p-4 min-w-[180px] flex flex-col">
            <div className="flex justify-between items-start mb-2">
              <div className="text-gray-400">
                <Layers className="h-5 w-5" />
              </div>
              <div className="text-primary font-medium">{group.level}</div>
            </div>
            <div className="mt-auto">
              <h3 className="font-medium mb-1">{group.name}</h3>
              <p className="text-gray-400 text-xs">Total Members: {group.memberCount}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
