import { useQuery } from "@tanstack/react-query";
import { CircleUser, UserPlus, Users, Search, Flame, Award, GraduationCap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface User {
  id: number;
  name: string;
  username: string;
  major?: string;
  streak: number;
  rank: number;
  points: number;
  avatarUrl: string | null;
}

export default function RecommendedBuddies() {
  const { toast } = useToast();

  const { data: recommendedBuddies, isLoading } = useQuery<User[]>({
    queryKey: ["/api/user/recommended-buddies"],
  });

  const sendBuddyRequest = async (buddyId: number) => {
    try {
      await apiRequest("POST", "/api/user/buddy-request", { buddyId });
      
      // Invalidate buddy requests query
      queryClient.invalidateQueries({ queryKey: ["/api/user/recommended-buddies"] });
      
      toast({
        title: "Request sent",
        description: "Study buddy request has been sent successfully.",
      });
    } catch (error) {
      toast({
        title: "Error sending request",
        description: "Failed to send buddy request. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <Card className="bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 shadow-lg overflow-hidden h-full">
        <CardHeader className="bg-gradient-to-r from-purple-900 to-indigo-900 border-b border-gray-700 pb-3">
          <CardTitle className="flex items-center gap-2 text-white">
            <Users className="h-5 w-5 text-purple-400" />
            Recommended Study Buddies
          </CardTitle>
          <CardDescription className="text-purple-200">
            Connect with these students to learn together
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-gray-800/50">
                <div className="flex items-center gap-3">
                  <Skeleton className="h-12 w-12 rounded-full" />
                  <div className="space-y-2">
                    <Skeleton className="h-5 w-32" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                </div>
                <Skeleton className="h-9 w-20 rounded-md" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!recommendedBuddies || recommendedBuddies.length === 0) {
    return (
      <Card className="bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 shadow-lg overflow-hidden h-full">
        <CardHeader className="bg-gradient-to-r from-purple-900 to-indigo-900 border-b border-gray-700 pb-3">
          <CardTitle className="flex items-center gap-2 text-white">
            <Users className="h-5 w-5 text-purple-400" />
            Recommended Study Buddies
          </CardTitle>
          <CardDescription className="text-purple-200">
            Connect with these students to learn together
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6 pb-6">
          <div className="text-center py-8 flex flex-col items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-gray-700 flex items-center justify-center">
              <Search className="h-8 w-8 text-gray-400" />
            </div>
            <p className="text-gray-400 max-w-xs">
              No study buddy recommendations available yet. Try exploring the Find StudyBuddies section to discover students with similar interests.
            </p>
            <Button
              variant="outline"
              className="mt-2 border-purple-600 text-purple-400 hover:bg-purple-900/20"
              onClick={() => window.location.href = '/find-buddies'}
            >
              Find Study Buddies
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Helper function to get avatar background color based on rank
  const getAvatarColor = (rank: number) => {
    if (rank >= 4) return "bg-gradient-to-br from-purple-600 to-purple-700";
    if (rank >= 3) return "bg-gradient-to-br from-blue-600 to-blue-700";
    if (rank >= 2) return "bg-gradient-to-br from-cyan-600 to-cyan-700";
    return "bg-gradient-to-br from-green-600 to-green-700";
  };

  return (
    <Card className="bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 shadow-lg overflow-hidden h-full">
      <CardHeader className="bg-gradient-to-r from-purple-900 to-indigo-900 border-b border-gray-700 pb-3">
        <CardTitle className="flex items-center gap-2 text-white">
          <Users className="h-5 w-5 text-purple-400" />
          Recommended Study Buddies
        </CardTitle>
        <CardDescription className="text-purple-200">
          Connect with these students to learn together
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-4">
        <div className="space-y-4">
          {recommendedBuddies.map((buddy) => (
            <div key={buddy.id} className="p-3 rounded-lg bg-gray-800/60 border border-gray-700 hover:bg-gray-800/90 transition-all duration-200 shadow-md">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  {buddy.avatarUrl ? (
                    <img 
                      src={buddy.avatarUrl} 
                      alt={buddy.name} 
                      className="h-12 w-12 rounded-full object-cover ring-2 ring-purple-500 shadow-md"
                    />
                  ) : (
                    <div className={`h-12 w-12 rounded-full ${getAvatarColor(buddy.rank)} flex items-center justify-center shadow-md`}>
                      <CircleUser className="h-7 w-7 text-white" />
                    </div>
                  )}
                  <div>
                    <p className="font-semibold text-white">{buddy.name}</p>
                    <div className="flex items-center flex-wrap gap-2 mt-1">
                      {buddy.major && (
                        <Badge variant="secondary" className="bg-gray-700 hover:bg-gray-600 text-xs px-2 py-0 h-5 flex items-center gap-1">
                          <GraduationCap className="h-3 w-3" /> {buddy.major}
                        </Badge>
                      )}
                      <Badge variant="secondary" className="bg-gray-700 hover:bg-gray-600 text-xs px-2 py-0 h-5 flex items-center gap-1">
                        <Award className="h-3 w-3 text-amber-400" /> Rank {buddy.rank}
                      </Badge>
                      {buddy.streak > 0 && (
                        <Badge variant="outline" className="text-xs border-red-600 text-red-400 px-2 py-0 h-5 flex items-center gap-1">
                          <Flame className="h-3 w-3 text-red-500" /> {buddy.streak} day streak
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex justify-end mt-2">
                <Button 
                  size="sm" 
                  className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white shadow-md transition-all duration-300 flex items-center gap-1"
                  onClick={() => sendBuddyRequest(buddy.id)}
                >
                  <UserPlus className="h-4 w-4" />
                  <span>Add Buddy</span>
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}