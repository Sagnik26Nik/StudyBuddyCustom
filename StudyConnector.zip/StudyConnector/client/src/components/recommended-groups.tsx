import { useQuery } from "@tanstack/react-query";
import { UsersRound, PlusCircle, BookOpen, Star, Gauge } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface StudyGroup {
  id: number;
  name: string;
  code: string;
  topic: string | null;
  memberCount: number;
  level: number;
  ownerId: number;
}

export default function RecommendedGroups() {
  const { toast } = useToast();

  const { data: recommendedGroups, isLoading } = useQuery<StudyGroup[]>({
    queryKey: ["/api/user/recommended-groups"],
  });

  const joinGroup = async (code: string) => {
    try {
      await apiRequest("POST", `/api/study-groups/${code}/join`);
      
      // Invalidate both recommended groups and user groups
      queryClient.invalidateQueries({ queryKey: ["/api/user/recommended-groups"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/study-groups"] });
      
      toast({
        title: "Group joined",
        description: "You have successfully joined the study group.",
      });
    } catch (error) {
      toast({
        title: "Error joining group",
        description: "Failed to join the group. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <Card className="bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 shadow-lg overflow-hidden h-full">
        <CardHeader className="bg-gradient-to-r from-blue-900 to-indigo-900 border-b border-gray-700 pb-3">
          <CardTitle className="flex items-center gap-2 text-white">
            <UsersRound className="h-5 w-5 text-blue-400" />
            Recommended Study Groups
          </CardTitle>
          <CardDescription className="text-blue-200">
            Join these groups to enhance your learning
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-gray-800/50">
                <div className="flex items-center gap-3">
                  <Skeleton className="h-12 w-12 rounded-full" />
                  <div className="space-y-2">
                    <Skeleton className="h-5 w-32" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                </div>
                <Skeleton className="h-9 w-20 rounded-md" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!recommendedGroups || recommendedGroups.length === 0) {
    return (
      <Card className="bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 shadow-lg overflow-hidden h-full">
        <CardHeader className="bg-gradient-to-r from-blue-900 to-indigo-900 border-b border-gray-700 pb-3">
          <CardTitle className="flex items-center gap-2 text-white">
            <UsersRound className="h-5 w-5 text-blue-400" />
            Recommended Study Groups
          </CardTitle>
          <CardDescription className="text-blue-200">
            Join these groups to enhance your learning
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6 pb-6">
          <div className="text-center py-8 flex flex-col items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-gray-700 flex items-center justify-center">
              <BookOpen className="h-8 w-8 text-gray-400" />
            </div>
            <p className="text-gray-400 max-w-xs">
              No recommended groups available yet. Try exploring the Find StudyGroups section to discover groups that match your interests.
            </p>
            <Button
              variant="outline"
              className="mt-2 border-blue-600 text-blue-400 hover:bg-blue-900/20"
              onClick={() => window.location.href = '/find-groups'}
            >
              Explore Study Groups
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Function to get a gradient color based on group level
  const getLevelColor = (level: number) => {
    if (level >= 4) return "from-purple-600 to-purple-700";
    if (level >= 3) return "from-blue-600 to-blue-700";
    if (level >= 2) return "from-cyan-600 to-cyan-700";
    return "from-green-600 to-green-700";
  };

  return (
    <Card className="bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 shadow-lg overflow-hidden h-full">
      <CardHeader className="bg-gradient-to-r from-blue-900 to-indigo-900 border-b border-gray-700 pb-3">
        <CardTitle className="flex items-center gap-2 text-white">
          <UsersRound className="h-5 w-5 text-blue-400" />
          Recommended Study Groups
        </CardTitle>
        <CardDescription className="text-blue-200">
          Join these groups to enhance your learning
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-4">
        <div className="space-y-4">
          {recommendedGroups.map((group) => (
            <div key={group.id} className="p-3 rounded-lg bg-gray-800/60 border border-gray-700 hover:bg-gray-800/90 transition-all duration-200 shadow-md">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className={`h-12 w-12 bg-gradient-to-br ${getLevelColor(group.level)} rounded-lg flex items-center justify-center shadow-md`}>
                    <UsersRound className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <p className="font-semibold text-white">{group.name}</p>
                    <div className="flex items-center flex-wrap gap-2 mt-1">
                      <Badge variant="secondary" className="bg-gray-700 hover:bg-gray-600 text-xs px-2 py-0 h-5 flex items-center gap-1">
                        <UsersRound className="h-3 w-3" /> {group.memberCount}
                      </Badge>
                      <Badge variant="secondary" className="bg-gray-700 hover:bg-gray-600 text-xs px-2 py-0 h-5 flex items-center gap-1">
                        <Star className="h-3 w-3 text-yellow-400" /> Level {group.level}
                      </Badge>
                      {group.topic && (
                        <Badge variant="outline" className="text-xs border-blue-600 text-blue-400 px-2 py-0 h-5 flex items-center gap-1">
                          <BookOpen className="h-3 w-3" /> {group.topic}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex justify-end mt-2">
                <Button 
                  size="sm" 
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-md transition-all duration-300 flex items-center gap-1"
                  onClick={() => joinGroup(group.code)}
                >
                  <PlusCircle className="h-4 w-4" />
                  <span>Join Group</span>
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}