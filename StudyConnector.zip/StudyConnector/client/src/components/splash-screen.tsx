import Logo from "./logo";

export default function SplashScreen() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-background text-white">
      <div className="mb-8">
        <Logo size={80} />
      </div>
      <h1 className="text-3xl font-bold">StudyBuddy</h1>
    </div>
  );
}
