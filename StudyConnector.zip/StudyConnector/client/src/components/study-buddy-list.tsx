import { useQuery } from "@tanstack/react-query";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";

interface StudyBuddy {
  id: number;
  userId: number;
  status: string;
  user: {
    id: number;
    name: string;
    streak: number;
    avatarUrl: string | null;
  };
}

export default function StudyBuddyList() {
  const { data: buddies, isLoading } = useQuery<StudyBuddy[]>({
    queryKey: ["/api/user/study-buddies"],
  });

  if (isLoading) {
    return (
      <div className="mt-6">
        <h2 className="text-xl font-bold mb-4">Your StudyBuddies</h2>
        <div className="flex space-x-6 overflow-x-auto pb-4">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="flex flex-col items-center">
              <Skeleton className="h-16 w-16 rounded-full mb-2" />
              <Skeleton className="h-4 w-16 mb-1" />
              <Skeleton className="h-3 w-12" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!buddies || buddies.length === 0) {
    return (
      <div className="mt-6">
        <h2 className="text-xl font-bold mb-4">Your StudyBuddies</h2>
        <div className="bg-gray-800 rounded-lg p-4 text-center">
          <p className="text-gray-400">You don't have any study buddies yet.</p>
          <p className="text-gray-400">Find study buddies to connect with!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mt-6">
      <h2 className="text-xl font-bold mb-4">Your StudyBuddies</h2>
      <div className="flex space-x-6 overflow-x-auto pb-4">
        {buddies.map((buddy) => (
          <div key={buddy.id} className="flex flex-col items-center">
            <div className="relative mb-2">
              <Avatar className="h-16 w-16 border-2 border-background">
                <AvatarImage src={buddy.user.avatarUrl || ''} />
                <AvatarFallback className="bg-primary/20 text-primary">
                  {buddy.user.name.substring(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 rounded-full border-2 border-background"></div>
            </div>
            <p className="font-medium">{buddy.user.name.split(' ')[0]}</p>
            <p className="text-gray-400 text-xs">Streak: {buddy.user.streak.toString().padStart(2, '0')}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
