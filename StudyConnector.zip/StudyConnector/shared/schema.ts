import { pgTable, text, serial, integer, varchar, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  major: text("major").notNull(),
  streak: integer("streak").default(0).notNull(),
  avatarUrl: text("avatar_url"),
  rank: integer("rank").default(0).notNull(),
  points: integer("points").default(0).notNull(),
});

export const studyGroups = pgTable("study_groups", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  code: text("code").notNull().unique(),
  topic: text("topic"),
  ownerId: integer("owner_id").notNull(),
  memberCount: integer("member_count").default(1).notNull(),
  level: integer("level").default(1).notNull(),
});

export const studyBuddies = pgTable("study_buddies", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  buddyId: integer("buddy_id").notNull(),
  status: text("status").notNull().default("pending"), // pending, accepted, rejected
});

export const groupMembers = pgTable("group_members", {
  id: serial("id").primaryKey(),
  groupId: integer("group_id").notNull(),
  userId: integer("user_id").notNull(),
  joinedAt: timestamp("joined_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  streak: true
});

export const insertStudyGroupSchema = createInsertSchema(studyGroups).omit({
  id: true,
  memberCount: true,
  level: true
});

export const insertStudyBuddySchema = createInsertSchema(studyBuddies).omit({
  id: true
});

export const insertGroupMemberSchema = createInsertSchema(groupMembers).omit({
  id: true,
  joinedAt: true
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertStudyGroup = z.infer<typeof insertStudyGroupSchema>;
export type StudyGroup = typeof studyGroups.$inferSelect;
export type InsertStudyBuddy = z.infer<typeof insertStudyBuddySchema>;
export type StudyBuddy = typeof studyBuddies.$inferSelect;
export type InsertGroupMember = z.infer<typeof insertGroupMemberSchema>;
export type GroupMember = typeof groupMembers.$inferSelect;
