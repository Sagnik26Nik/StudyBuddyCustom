import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import { insertStudyGroupSchema, insertStudyBuddySchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Get all study groups
  app.get("/api/study-groups", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    // For demonstration purposes, let's show some sample study groups
    // In a real app, we'd use storage.getAllStudyGroups()
    const groups = await storage.getAllStudyGroups();
    
    // Add some sample study groups for demonstration
    const sampleGroups = [
      {
        id: 201,
        name: "CS Study Circle",
        code: "CS123",
        topic: "Data Structures & Algorithms",
        memberCount: 12,
        level: 3,
        ownerId: 101
      },
      {
        id: 202,
        name: "Physics Lab Group",
        code: "PHY456",
        topic: "Quantum Mechanics",
        memberCount: 8,
        level: 2,
        ownerId: 102
      },
      {
        id: 203,
        name: "Math Masters",
        code: "MTH789",
        topic: "Linear Algebra",
        memberCount: 15,
        level: 4,
        ownerId: 103
      }
    ];
    
    // Combine the user's groups with sample groups
    const combinedGroups = [...groups, ...sampleGroups.filter(g => !groups.some(userGroup => userGroup.code === g.code))];
    
    res.json(combinedGroups);
  });

  // Get user's study groups
  app.get("/api/user/study-groups", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const userId = req.user.id;
    const groups = await storage.getUserStudyGroups(userId);
    res.json(groups);
  });
  
  // Get recommended study groups for a user
  app.get("/api/user/recommended-groups", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const userId = req.user.id;
    const currentUser = await storage.getUser(userId);
    
    if (!currentUser) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Get all groups
    const allGroups = await storage.getAllStudyGroups();
    
    // Get user's existing groups
    const userGroups = await storage.getUserStudyGroups(userId);
    const userGroupIds = new Set(userGroups.map(group => group.id));
    
    // Filter out groups the user is already a member of
    const potentialGroups = allGroups.filter(group => !userGroupIds.has(group.id));
    
    // Get group members for potential scoring
    const groupMembersMap = new Map();
    
    await Promise.all(
      potentialGroups.map(async group => {
        const members = await storage.getGroupMembers(group.id);
        groupMembersMap.set(group.id, members);
      })
    );
    
    // Calculate recommendation score based on:
    // 1. Group activity (level)
    // 2. Number of members (more members might indicate a better/more active group)
    // 3. Group topics that match user interests (if applicable)
    const recommendedGroups = potentialGroups
      .map(group => {
        let score = 0;
        
        // Active groups with higher levels get a higher score
        score += group.level * 2;
        
        // Groups with more members get a higher score (up to a point)
        score += Math.min(group.memberCount, 10);
        
        return {
          group,
          score
        };
      })
      .sort((a, b) => b.score - a.score) // Sort by score descending
      .slice(0, 5) // Take top 5
      .map(item => item.group); // Return only the group objects
    
    res.json(recommendedGroups);
  });

  // Create new study group
  app.post("/api/study-groups", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const userId = req.user.id;
      const validator = insertStudyGroupSchema.parse({
        ...req.body,
        ownerId: userId
      });
      
      const group = await storage.createStudyGroup(validator);
      res.status(201).json(group);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      throw error;
    }
  });

  // Join a study group
  app.post("/api/study-groups/:code/join", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const code = req.params.code;
    const userId = req.user.id;
    
    const group = await storage.getStudyGroupByCode(code);
    if (!group) {
      return res.status(404).json({ message: "Study group not found" });
    }
    
    const alreadyMember = await storage.isUserInGroup(userId, group.id);
    if (alreadyMember) {
      return res.status(400).json({ message: "Already a member of this group" });
    }
    
    const membership = await storage.addGroupMember({
      groupId: group.id,
      userId
    });
    
    res.status(201).json(membership);
  });

  // Get user's study buddies
  app.get("/api/user/study-buddies", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const userId = req.user.id;
    const buddies = await storage.getStudyBuddiesByUserId(userId);
    
    // Get the actual user objects for each buddy
    const buddyDetails = await Promise.all(
      buddies.map(async (buddy) => {
        const otherUserId = buddy.userId === userId ? buddy.buddyId : buddy.userId;
        const user = await storage.getUser(otherUserId);
        return {
          id: buddy.id,
          userId: otherUserId,
          status: buddy.status,
          user
        };
      })
    );
    
    res.json(buddyDetails);
  });
  
  // Get recommended study buddies for a user
  app.get("/api/user/recommended-buddies", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const userId = req.user.id;
    const currentUser = await storage.getUser(userId);
    
    if (!currentUser) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Get all users
    const allUsers = await storage.getAllUsers();
    
    // Filter out the current user
    const otherUsers = allUsers.filter(user => user.id !== userId);
    
    // Get existing buddies
    const existingBuddies = await storage.getStudyBuddiesByUserId(userId);
    const existingBuddyIds = new Set(
      existingBuddies.map(buddy => 
        buddy.userId === userId ? buddy.buddyId : buddy.userId
      )
    );
    
    // Filter out existing buddies
    const potentialBuddies = otherUsers.filter(
      user => !existingBuddyIds.has(user.id)
    );
    
    // Calculate recommendation score based on a combination of:
    // 1. Similar majors (if applicable)
    // 2. Activity level (streak)
    // 3. Rank/points
    const recommendedBuddies = potentialBuddies
      .map(user => {
        // Calculate recommendation score
        let score = 0;
        
        // Streak similarity (active users match well with other active users)
        score += Math.min(user.streak, currentUser.streak);
        
        // Similar rank/level
        score += 10 - Math.abs(user.rank - currentUser.rank);
        
        return {
          user,
          score
        };
      })
      .sort((a, b) => b.score - a.score) // Sort by score descending
      .slice(0, 5) // Take top 5
      .map(item => item.user); // Return only the user objects
    
    res.json(recommendedBuddies);
  });

  // Get pending buddy requests
  app.get("/api/user/buddy-requests", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const userId = req.user.id;
    const requests = await storage.getPendingBuddyRequests(userId);
    
    // Get the requesting user details
    const requestDetails = await Promise.all(
      requests.map(async (request) => {
        const requester = await storage.getUser(request.userId);
        return {
          id: request.id,
          userId: request.userId,
          status: request.status,
          user: requester
        };
      })
    );
    
    res.json(requestDetails);
  });

  // Send buddy request
  app.post("/api/user/buddy-request", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const userId = req.user.id;
      const validator = insertStudyBuddySchema.parse({
        ...req.body,
        userId
      });
      
      if (validator.userId === validator.buddyId) {
        return res.status(400).json({ message: "Cannot add yourself as a buddy" });
      }
      
      const buddy = await storage.createStudyBuddy(validator);
      res.status(201).json(buddy);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      throw error;
    }
  });

  // Accept a buddy request
  app.post("/api/user/buddy-request/:id/accept", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const requestId = parseInt(req.params.id);
    if (isNaN(requestId)) {
      return res.status(400).json({ message: "Invalid request ID" });
    }
    
    const buddy = await storage.acceptBuddyRequest(requestId);
    if (!buddy) {
      return res.status(404).json({ message: "Buddy request not found" });
    }
    
    res.json(buddy);
  });

  // Reject a buddy request
  app.post("/api/user/buddy-request/:id/reject", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const requestId = parseInt(req.params.id);
    if (isNaN(requestId)) {
      return res.status(400).json({ message: "Invalid request ID" });
    }
    
    const buddy = await storage.rejectBuddyRequest(requestId);
    if (!buddy) {
      return res.status(404).json({ message: "Buddy request not found" });
    }
    
    res.json(buddy);
  });

  // Search users to find study buddies
  app.get("/api/users/search", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const query = req.query.q as string || "";
    const major = req.query.major as string || "";
    
    // For demonstration purposes, let's create some sample users
    // In a real app, this would come from the database
    const sampleUsers = [
      {
        id: 101,
        name: "Alex Johnson",
        major: "Computer Science",
        avatarUrl: null,
      },
      {
        id: 102,
        name: "Jamie Smith",
        major: "Physics",
        avatarUrl: null,
      },
      {
        id: 103,
        name: "Taylor Rodriguez",
        major: "Mathematics",
        avatarUrl: null,
      },
      {
        id: 104,
        name: "Jordan Lee",
        major: "Biology",
        avatarUrl: null,
      },
      {
        id: 105,
        name: "Casey Williams",
        major: "Chemistry",
        avatarUrl: null,
      }
    ];
    
    // Filter users based on query and major
    const filtered = sampleUsers.filter(user => {
      if (user.id === req.user.id) return false;
      
      if (query && major) {
        return (
          user.name.toLowerCase().includes(query.toLowerCase()) || 
          user.major.toLowerCase().includes(query.toLowerCase())
        ) && user.major.toLowerCase().includes(major.toLowerCase());
      }
      
      if (query) {
        return user.name.toLowerCase().includes(query.toLowerCase()) ||
               user.major.toLowerCase().includes(query.toLowerCase());
      }
      
      if (major) {
        return user.major.toLowerCase().includes(major.toLowerCase());
      }
      
      return true;
    });
    
    res.json(filtered);
  });

  const httpServer = createServer(app);
  return httpServer;
}
