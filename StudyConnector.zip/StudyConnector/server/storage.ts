import { 
  users, type User, type InsertUser,
  studyGroups, type StudyGroup, type InsertStudyGroup,
  studyBuddies, type StudyBuddy, type InsertStudyBuddy,
  groupMembers, type GroupMember, type InsertGroupMember
} from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";
import type { Store as SessionStore } from "express-session";

// Collection of interfaces for CRUD operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStreak(userId: number, streak: number): Promise<User | undefined>;
  updateUserRank(userId: number, rank: number, points: number): Promise<User | undefined>;
  getTopRankedUsers(limit?: number): Promise<User[]>;
  getAllUsers(): Promise<User[]>;
  
  // Study Group operations
  createStudyGroup(group: InsertStudyGroup): Promise<StudyGroup>;
  getStudyGroup(id: number): Promise<StudyGroup | undefined>;
  getStudyGroupByCode(code: string): Promise<StudyGroup | undefined>;
  getAllStudyGroups(): Promise<StudyGroup[]>;
  getUserStudyGroups(userId: number): Promise<StudyGroup[]>;
  incrementStudyGroupLevel(groupId: number): Promise<StudyGroup | undefined>;
  
  // Study Buddy operations
  createStudyBuddy(buddy: InsertStudyBuddy): Promise<StudyBuddy>;
  getStudyBuddiesByUserId(userId: number): Promise<StudyBuddy[]>;
  getPendingBuddyRequests(userId: number): Promise<StudyBuddy[]>;
  acceptBuddyRequest(id: number): Promise<StudyBuddy | undefined>;
  rejectBuddyRequest(id: number): Promise<StudyBuddy | undefined>;
  
  // Group Member operations
  addGroupMember(member: InsertGroupMember): Promise<GroupMember>;
  getGroupMembers(groupId: number): Promise<GroupMember[]>;
  isUserInGroup(userId: number, groupId: number): Promise<boolean>;
  
  // Session store
  sessionStore: SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private studyGroups: Map<number, StudyGroup>;
  private studyBuddies: Map<number, StudyBuddy>;
  private groupMembers: Map<number, GroupMember>;
  sessionStore: SessionStore;
  private userIdCounter: number;
  private groupIdCounter: number;
  private buddyIdCounter: number;
  private memberIdCounter: number;

  constructor() {
    this.users = new Map();
    this.studyGroups = new Map();
    this.studyBuddies = new Map();
    this.groupMembers = new Map();
    this.userIdCounter = 1;
    this.groupIdCounter = 1;
    this.buddyIdCounter = 1;
    this.memberIdCounter = 1;
    
    const MemoryStore = createMemoryStore(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase()
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { 
      ...insertUser, 
      id, 
      streak: 0, 
      avatarUrl: null,
      rank: 0,
      points: 0
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserStreak(userId: number, streak: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const updatedUser = { ...user, streak };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async updateUserRank(userId: number, rank: number, points: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const updatedUser = { ...user, rank, points };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async getTopRankedUsers(limit: number = 10): Promise<User[]> {
    return Array.from(this.users.values())
      .sort((a, b) => b.points - a.points)
      .slice(0, limit);
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Study Group operations
  async createStudyGroup(insertGroup: InsertStudyGroup): Promise<StudyGroup> {
    const id = this.groupIdCounter++;
    const group: StudyGroup = { 
      ...insertGroup, 
      id, 
      memberCount: 1, 
      level: 1,
      topic: insertGroup.topic || null 
    };
    this.studyGroups.set(id, group);
    
    // Add owner as a member
    await this.addGroupMember({
      groupId: id,
      userId: insertGroup.ownerId
    });
    
    return group;
  }

  async getStudyGroup(id: number): Promise<StudyGroup | undefined> {
    return this.studyGroups.get(id);
  }

  async getStudyGroupByCode(code: string): Promise<StudyGroup | undefined> {
    return Array.from(this.studyGroups.values()).find(
      (group) => group.code === code
    );
  }

  async getAllStudyGroups(): Promise<StudyGroup[]> {
    return Array.from(this.studyGroups.values());
  }

  async getUserStudyGroups(userId: number): Promise<StudyGroup[]> {
    const userMemberships = Array.from(this.groupMembers.values())
      .filter((member) => member.userId === userId)
      .map((member) => member.groupId);
    
    return Array.from(this.studyGroups.values())
      .filter((group) => userMemberships.includes(group.id));
  }

  async incrementStudyGroupLevel(groupId: number): Promise<StudyGroup | undefined> {
    const group = await this.getStudyGroup(groupId);
    if (!group) return undefined;
    
    const updatedGroup = { ...group, level: group.level + 1 };
    this.studyGroups.set(groupId, updatedGroup);
    return updatedGroup;
  }

  // Study Buddy operations
  async createStudyBuddy(insertBuddy: InsertStudyBuddy): Promise<StudyBuddy> {
    const id = this.buddyIdCounter++;
    const buddy = { 
      userId: insertBuddy.userId, 
      buddyId: insertBuddy.buddyId,
      id,
      status: "pending" 
    } as StudyBuddy;
    this.studyBuddies.set(id, buddy);
    return buddy;
  }

  async getStudyBuddiesByUserId(userId: number): Promise<StudyBuddy[]> {
    return Array.from(this.studyBuddies.values())
      .filter((buddy) => 
        (buddy.userId === userId || buddy.buddyId === userId) && 
        buddy.status === "accepted"
      );
  }

  async getPendingBuddyRequests(userId: number): Promise<StudyBuddy[]> {
    return Array.from(this.studyBuddies.values())
      .filter((buddy) => 
        buddy.buddyId === userId && 
        buddy.status === "pending"
      );
  }

  async acceptBuddyRequest(id: number): Promise<StudyBuddy | undefined> {
    const buddy = this.studyBuddies.get(id);
    if (!buddy) return undefined;
    
    const updatedBuddy = { ...buddy, status: "accepted" };
    this.studyBuddies.set(id, updatedBuddy);
    return updatedBuddy;
  }

  async rejectBuddyRequest(id: number): Promise<StudyBuddy | undefined> {
    const buddy = this.studyBuddies.get(id);
    if (!buddy) return undefined;
    
    const updatedBuddy = { ...buddy, status: "rejected" };
    this.studyBuddies.set(id, updatedBuddy);
    return updatedBuddy;
  }

  // Group Member operations
  async addGroupMember(insertMember: InsertGroupMember): Promise<GroupMember> {
    const id = this.memberIdCounter++;
    const member: GroupMember = { 
      ...insertMember, 
      id, 
      joinedAt: new Date() 
    };
    this.groupMembers.set(id, member);
    
    // Increment member count in the group
    const group = await this.getStudyGroup(insertMember.groupId);
    if (group) {
      const updatedGroup = { 
        ...group, 
        memberCount: group.memberCount + 1 
      };
      this.studyGroups.set(group.id, updatedGroup);
    }
    
    return member;
  }

  async getGroupMembers(groupId: number): Promise<GroupMember[]> {
    return Array.from(this.groupMembers.values())
      .filter((member) => member.groupId === groupId);
  }

  async isUserInGroup(userId: number, groupId: number): Promise<boolean> {
    return Array.from(this.groupMembers.values())
      .some((member) => 
        member.groupId === groupId && 
        member.userId === userId
      );
  }
}

export const storage = new MemStorage();
